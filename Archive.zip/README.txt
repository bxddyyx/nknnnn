-- Adopt Me Checker v2 By Baby Goth#0001--
Requirements:
- Synapse X 
- Roblox Client
- Python 3.7.5 x64

==================
Installation:

1.
Download Synapse X and extract it's folder here, so that the
"Synapse-X" folder is in the GameScraper folder

2.
Open Synapse X and log into your account, and then enable Auto-Attach

3.
Run setup.bat

4.
Put your cookies into cookies.txt

5.
Launch run.bat
====================

The accounts will be output into a .csv file in the "output" folder.
====================

https://v3rmillion.net/member.php?action=profile&uid=1755047